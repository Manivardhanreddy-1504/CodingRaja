package com.examly.springapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.Account;
import com.examly.springapp.repository.AccountRepo;

@Service
public class AccountService {
    @Autowired
    private AccountRepo accountRepo;

    public Account createAccount(Account account){
        return accountRepo.save(account);
    }

    public List<Account> getAllAccounts(){
        return accountRepo.findAll();
    }

    public boolean deleteAccount(int accountId){
        Account account= accountRepo.findById(accountId).orElse(null);
        if(account!=null){
            accountRepo.deleteById(accountId);
            return true;
        }
        return false;
    }
}
