package com.examly.springapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;

@Service
public class UserService {
    @Autowired
    private UserRepo userRepo;

    public User registerUser(User user){
        return userRepo.save(user);
    }

    public User loginUser(User user){
        return userRepo.userLogin(user.getUsername(), user.getPassword());
    }

}
