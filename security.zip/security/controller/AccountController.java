package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Account;
import com.examly.springapp.service.AccountService;

@RestController
public class AccountController {
    @Autowired
    private AccountService accountService;
    @PostMapping("/account")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Account> createAccount(@RequestBody Account account){
        Account createdAccount= accountService.createAccount(account);
        return ResponseEntity.status(201).body(createdAccount);
    }

    @GetMapping("/account")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Account>> getAllAccounts(){
        List<Account> accounts= accountService.getAllAccounts();
        return ResponseEntity.status(200).body(accounts);
    }

    @DeleteMapping("/account/{accountId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Boolean> deleteAccount(@PathVariable int accountId){
        boolean deleted= accountService.deleteAccount(accountId);
        return ResponseEntity.status(200).body(deleted);
    }
}
