package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.examly.springapp.model.User;

@Repository
public interface UserRepo extends JpaRepository<User, Integer>{

    @Query("select u from User u where u.username=?1 and u.password=?2")
    User userLogin(String username, String password);

    @Query("select u from User u where u.username=?1")
    User getUser(String username);

    //user findByUsernameAndPassword(String username, string Password)
}
